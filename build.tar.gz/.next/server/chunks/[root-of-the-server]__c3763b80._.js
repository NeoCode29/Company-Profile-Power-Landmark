module.exports={29549:function(e){var{g:t,__dirname:r,m:s,e:n}=e;s.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},83943:function(e){var{g:t,__dirname:r,m:s,e:n}=e;s.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},86103:function(e){var{g:t,__dirname:r,m:s,e:n}=e;s.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},45935:function(e){var{g:t,__dirname:r,m:s,e:n}=e;s.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},23430:function(e){var{g:t,__dirname:r,m:s,e:n}=e;s.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},29295:function(e){var{g:t,__dirname:r,m:s,e:n}=e;s.exports=e.x("crypto",()=>require("crypto"))},52670:function(e){var{g:t,__dirname:r,m:s,e:n}=e;s.exports=e.x("next/dist/compiled/next-server/app-route-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-route-turbo.runtime.prod.js"))},28191:function(e){var{g:t,__dirname:r,m:s,e:n}=e},31841:e=>{"use strict";var{g:t,__dirname:r}=e;{e.s({GET:()=>i,OPTIONS:()=>l,POST:()=>a});var s=e.i(25427),n=e.i(29295);let t={MERCHANT_CODE:process.env.IPAY88_MERCHANT_CODE||"ID00001",MERCHANT_KEY:process.env.IPAY88_MERCHANT_KEY||"your-merchant-key"};function o(e){let{MerchantCode:r,PaymentId:s,RefNo:o,Amount:a,Currency:i,Status:l,Signature:c}=e,p=`||${t.MERCHANT_KEY}||${r}||${s}||${o}||${a}||${i}||${l}||`;return n.default.createHash("sha256").update(p).digest("hex").toLowerCase()===(c||"").toLowerCase()}async function a(e){try{console.log("🔄 iPay88 Response URL POST called");let t=e.headers.get("origin");console.log("Request origin:",t);let r=e.headers.get("content-type")||"",n={};r.includes("application/json")?n=await e.json():(await e.formData()).forEach((e,t)=>{n[t]=e});let{MerchantCode:a="",RefNo:i="",TransId:l="",Amount:c="",Status:p="",PaymentId:d="",Signature:u="",Currency:m="IDR"}=n;if(console.log("🔎 Parsed iPay88 Response:",{MerchantCode:a,RefNo:i,TransId:l,Amount:c,Status:p,PaymentId:d,Signature:u?"***PROVIDED***":"***MISSING***"}),u&&a&&"ID00000"!==a){let e=o({MerchantCode:a,PaymentId:d,RefNo:i,Amount:c,Currency:m,Status:p,Signature:u});console.log("Signature valid:",e)}let h=process.env.NEXTAUTH_URL||"http://localhost:3000",g=new URL("/payment/status",h);g.searchParams.set("orderNumber",i),g.searchParams.set("status","1"===p?"success":"failed"),g.searchParams.set("source","ipay88"),g.searchParams.set("transId",l||""),g.searchParams.set("amount",c||"");let y=`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Payment Response</title>
        <meta charset="utf-8">
    </head>
    <body>
        <div style="text-align: center; padding: 50px; font-family: Arial, sans-serif;">
            <h2>Processing payment response...</h2>
            <p>Please wait while we redirect you.</p>
            <script>
                setTimeout(function() {
                    window.top.location.href = "${g.toString()}";
                }, 500);
            </script>
        </div>
    </body>
    </html>`;return new s.NextResponse(y,{status:200,headers:{"Content-Type":"text/html; charset=utf-8","Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET, POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type"}})}catch(r){console.error("❌ Error handling iPay88 response:",r);let e=new URL("/payment/finish",process.env.NEXTAUTH_URL||"http://localhost:3000");e.searchParams.set("status","failed"),e.searchParams.set("error","processing_error");let t=`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Payment Error</title>
        <meta charset="utf-8">
    </head>
    <body>
        <div style="text-align: center; padding: 50px; font-family: Arial, sans-serif;">
            <h2>Payment processing error</h2>
            <p>Redirecting to finish page...</p>
            <script>
                setTimeout(function() {
                    window.top.location.href = "${e.toString()}";
                }, 1000);
            </script>
        </div>
    </body>
    </html>`;return new s.NextResponse(t,{status:200,headers:{"Content-Type":"text/html; charset=utf-8","X-Frame-Options":"SAMEORIGIN","Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET, POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type"}})}}async function i(e){let{searchParams:t}=new URL(e.url);console.log("🔄 iPay88 Response URL GET called with params:",Object.fromEntries(t.entries()));let r=t.get("MerchantCode"),n=t.get("RefNo")||t.get("orderNumber"),a=t.get("Status")||t.get("status"),i=t.get("TransId")||t.get("transId"),l=t.get("Amount")||t.get("amount"),c=t.get("PaymentId"),p=t.get("Signature"),d=t.get("Currency")||"IDR";p&&c&&console.log("Signature valid (GET):",o({MerchantCode:r||"",PaymentId:c,RefNo:n||"",Amount:l||"",Currency:d,Status:a||"",Signature:p})),console.log("Extracted GET parameters:",{MerchantCode:r,RefNo:n,Status:a,TransId:i,Amount:l,PaymentId:c,Signature:p?"***PROVIDED***":"***MISSING***"});let u="failed";"1"===a||"success"===a?u="success":("0"===a||"failed"===a)&&(u="failed");let m=new URL("/payment/status",process.env.NEXTAUTH_URL||"http://localhost:3000");m.searchParams.set("orderNumber",n||""),m.searchParams.set("status",u),m.searchParams.set("source","ipay88"),m.searchParams.set("transId",i||""),m.searchParams.set("amount",l||""),console.log("🔗 Redirecting to:",m.toString());let h=`
  <!DOCTYPE html>
  <html>
  <head>
      <title>Payment Response</title>
      <meta charset="utf-8">
  </head>
  <body>
      <div style="text-align: center; padding: 50px; font-family: Arial, sans-serif;">
          <h2>Processing payment response...</h2>
          <p>Status: ${u}</p>
          <p>Order: ${n||"Unknown"}</p>
          <p>Please wait while we redirect you.</p>
          <script>
              console.log('Redirecting to:', "${m.toString()}");
              setTimeout(function() {
                  window.location.href = "${m.toString()}";
              }, 1000);
          </script>
      </div>
  </body>
  </html>`;return new s.NextResponse(h,{status:200,headers:{"Content-Type":"text/html; charset=utf-8","Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET, POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type"}})}async function l(e){return new s.NextResponse(null,{status:200,headers:{"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET, POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Max-Age":"86400"}})}}},15208:e=>{"use strict";var{g:t,__dirname:r}=e;{e.s({patchFetch:()=>i,routeModule:()=>t,serverHooks:()=>c,workAsyncStorage:()=>r,workUnitAsyncStorage:()=>l});var s=e.i(54885),n=e.i(14689),o=e.i(25402),a=e.i(31841);let t=new s.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/payment/response/route",pathname:"/api/payment/response",filename:"route",bundlePath:""},resolvedPagePath:"[project]/src/app/api/payment/response/route.ts",nextConfigOutput:"",userland:a}),{workAsyncStorage:r,workUnitAsyncStorage:l,serverHooks:c}=t;function i(){return(0,o.patchFetch)({workAsyncStorage:r,workUnitAsyncStorage:l})}}}};

//# sourceMappingURL=%5Broot-of-the-server%5D__c3763b80._.js.map