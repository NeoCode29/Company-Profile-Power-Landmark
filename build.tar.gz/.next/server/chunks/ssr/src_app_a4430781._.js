module.exports={10198:a=>{var{g:b,__dirname:c}=a;a.v("/_next/static/media/favicon.45db1c09.ico")},38667:a=>{"use strict";var{g:b,__dirname:c}=a;{a.s({default:()=>b});let b={src:a.i(10198).default,width:256,height:256}}}};

//# sourceMappingURL=src_app_a4430781._.js.map