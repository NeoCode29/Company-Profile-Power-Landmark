globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/a49beb0b156a5935.js",
      "static/chunks/254a0417479129ee.js",
      "static/chunks/f96b76b379bc80df.js"
    ],
    "/_error": [
      "static/chunks/35f543649c6536df.js",
      "static/chunks/254a0417479129ee.js",
      "static/chunks/d7858d7ac7c8b0c4.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/ec548c7ce307cf6d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/243ed931d94d82cb.js",
    "static/chunks/ff10d0bd43cbf33c.js",
    "static/chunks/d71e9ae5995ef25a.js",
    "static/chunks/f5f75c9178879213.js",
    "static/chunks/0169981b3c98ef9a.js",
    "static/chunks/6a2f5956d3115d65.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];