globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/a49beb0b156a5935.js",
      "static/chunks/7ac199b28a62caf2.js",
      "static/chunks/dce8cb97187db719.js"
    ],
    "/_error": [
      "static/chunks/35f543649c6536df.js",
      "static/chunks/7ac199b28a62caf2.js",
      "static/chunks/690a7b25b452dabe.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/ec548c7ce307cf6d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/3bb65ff5c8eeead9.js",
    "static/chunks/ff10d0bd43cbf33c.js",
    "static/chunks/d71e9ae5995ef25a.js",
    "static/chunks/f5f75c9178879213.js",
    "static/chunks/cef67fe2dfc09a77.js",
    "static/chunks/5a39c0e0f7ae64f6.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];