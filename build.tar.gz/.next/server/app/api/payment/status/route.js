const CHUNK_PUBLIC_PATH = "server/app/api/payment/status/route.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__d1a93a94._.js");
runtime.loadChunk("server/chunks/node_modules_next_64e7e0ea._.js");
runtime.getOrInstantiateRuntimeModule(8658, CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule(37866, CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule(37866, CHUNK_PUBLIC_PATH).exports;
