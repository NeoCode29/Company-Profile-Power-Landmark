const CHUNK_PUBLIC_PATH = "server/app/api/payment/route.js";
const runtime = require("../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__01467c5b._.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__87f2a002._.js");
runtime.loadChunk("server/chunks/node_modules_next_64e7e0ea._.js");
runtime.getOrInstantiateRuntimeModule(82190, CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule(94384, CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule(94384, CHUNK_PUBLIC_PATH).exports;
