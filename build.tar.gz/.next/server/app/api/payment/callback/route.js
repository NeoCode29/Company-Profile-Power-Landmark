const CHUNK_PUBLIC_PATH = "server/app/api/payment/callback/route.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__b7ba9a9c._.js");
runtime.loadChunk("server/chunks/node_modules_next_64e7e0ea._.js");
runtime.getOrInstantiateRuntimeModule(90106, CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule(87858, CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule(87858, CHUNK_PUBLIC_PATH).exports;
