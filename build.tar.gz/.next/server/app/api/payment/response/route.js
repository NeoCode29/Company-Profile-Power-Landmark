const CHUNK_PUBLIC_PATH = "server/app/api/payment/response/route.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__c3763b80._.js");
runtime.loadChunk("server/chunks/node_modules_next_64e7e0ea._.js");
runtime.getOrInstantiateRuntimeModule(28191, CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule(15208, CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule(15208, CHUNK_PUBLIC_PATH).exports;
