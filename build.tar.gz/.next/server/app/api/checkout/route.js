const CHUNK_PUBLIC_PATH = "server/app/api/checkout/route.js";
const runtime = require("../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__5593abb5._.js");
runtime.loadChunk("server/chunks/_7218a95f._.js");
runtime.loadChunk("server/chunks/node_modules_next_64e7e0ea._.js");
runtime.getOrInstantiateRuntimeModule(37264, CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule(7911, CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule(7911, CHUNK_PUBLIC_PATH).exports;
