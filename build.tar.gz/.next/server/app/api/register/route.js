const CHUNK_PUBLIC_PATH = "server/app/api/register/route.js";
const runtime = require("../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__a8937938._.js");
runtime.loadChunk("server/chunks/node_modules_next_64e7e0ea._.js");
runtime.getOrInstantiateRuntimeModule(81773, CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule(21939, CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule(21939, CHUNK_PUBLIC_PATH).exports;
