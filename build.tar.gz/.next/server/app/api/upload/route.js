const CHUNK_PUBLIC_PATH = "server/app/api/upload/route.js";
const runtime = require("../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__d6b40b33._.js");
runtime.loadChunk("server/chunks/_7218a95f._.js");
runtime.loadChunk("server/chunks/node_modules_next_64e7e0ea._.js");
runtime.getOrInstantiateRuntimeModule(87923, CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule(69583, CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule(69583, CHUNK_PUBLIC_PATH).exports;
