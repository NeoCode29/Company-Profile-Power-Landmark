const CHUNK_PUBLIC_PATH = "server/app/api/upload/delete/route.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__d47bb837._.js");
runtime.loadChunk("server/chunks/_7218a95f._.js");
runtime.loadChunk("server/chunks/node_modules_next_64e7e0ea._.js");
runtime.getOrInstantiateRuntimeModule(30195, CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule(97876, CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule(97876, CHUNK_PUBLIC_PATH).exports;
