__turbopack_load_page_chunks__("/_app", [
  "static/chunks/a49beb0b156a5935.js",
  "static/chunks/254a0417479129ee.js",
  "static/chunks/f96b76b379bc80df.js"
])
