__turbopack_load_page_chunks__("/_app", [
  "static/chunks/a49beb0b156a5935.js",
  "static/chunks/7ac199b28a62caf2.js",
  "static/chunks/dce8cb97187db719.js"
])
