__turbopack_load_page_chunks__("/_error", [
  "static/chunks/35f543649c6536df.js",
  "static/chunks/254a0417479129ee.js",
  "static/chunks/d7858d7ac7c8b0c4.js"
])
