__turbopack_load_page_chunks__("/_error", [
  "static/chunks/35f543649c6536df.js",
  "static/chunks/7ac199b28a62caf2.js",
  "static/chunks/690a7b25b452dabe.js"
])
